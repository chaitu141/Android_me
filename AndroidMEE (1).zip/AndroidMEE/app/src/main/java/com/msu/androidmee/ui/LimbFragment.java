package com.msu.androidmee.ui;

import java.util.List;
import com.msu.androidmee.R;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.NonNull;
import android.view.LayoutInflater;
import androidx.fragment.app.Fragment;
import android.widget.ImageView;
import android.view.ViewGroup;







public class LimbFragment extends Fragment {
    public static final String LIMB_IMAGE_ID = "limb_img_id";
    public static final String LIMB_IMAGE_LIST = "limb_img_list";
    private List<Integer> limbList;
    private int limbID;


    public void setLimbList(List<Integer> limbList) {
        this.limbList = limbList;
    }


    public void setLimbID(int limbID) {
        this.limbID = limbID;
    }

    public LimbFragment() {

    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            limbID = savedInstanceState.getInt(LIMB_IMAGE_ID);
            limbList = savedInstanceState.getIntegerArrayList(LIMB_IMAGE_LIST);
        }

        View root = inflater.inflate(R.layout.fragment_body_part, container, false);

        final ImageView limbImageView = root.findViewById(R.id.limbImageView);


        if (limbImageView != null && limbList != null)
            limbImageView.setImageResource(limbList.get(limbID));


        assert limbImageView != null;
        limbImageView.setOnClickListener(view -> {
            if (limbID < limbList.size() - 1)
                limbID++;
            else
                limbID = 0;
            limbImageView.setImageResource(limbList.get(limbID));
        });
        return root;
    }
}