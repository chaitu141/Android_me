package com.msu.androidmee.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;

import com.msu.androidmee.R;
import com.msu.androidmee.data.AndroidImageAssets;

public class AndroidMeActivity extends AppCompatActivity {
    private int headIndex;
    private int bodyIndex;
    private int legIndex;

    public AndroidMeActivity(){

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_android_me);
        FragmentManager fragmentManager = getSupportFragmentManager();
        Bundle b=getIntent().getExtras();


        //HeadFragment
        LimbFragment headFragment = new LimbFragment();
        headFragment.setLimbList(AndroidImageAssets.getHeads());
        if(b != null)
            headFragment.setLimbID(b.getInt("headIndex"));
        fragmentManager.beginTransaction().add(R.id.headContainer, headFragment).commit();

        //Body fragment
        LimbFragment bodyFragment = new LimbFragment();
        bodyFragment.setLimbList(AndroidImageAssets.getBodies());
        if(b != null)
            bodyFragment.setLimbID(b.getInt("bodyIndex"));
        fragmentManager.beginTransaction().add(R.id.bodyContainer, bodyFragment).commit();

        //Legs fragment
        LimbFragment legFragment = new LimbFragment();
        legFragment.setLimbList(AndroidImageAssets.getLegs());
        if(b != null)
            legFragment.setLimbID(b.getInt("legIndex"));
        fragmentManager.beginTransaction().add(R.id.legContainer, legFragment).commit();

    }
}