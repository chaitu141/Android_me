package com.msu.androidmee.ui;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;


import android.os.Bundle;
import android.view.View;

import com.msu.androidmee.R;
import android.widget.GridView;
import com.msu.androidmee.data.AndroidImageAssets;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements EveryItemFragment.OnItemClicked {
    private boolean isTwoPanel;

    private int index_HEAD;
    private int index_BODY;
    private int index_LEG;
    private static final int COLUMN_COUNT = 2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        initializeLimbFragments();

    }

    @Override
    public void onItemPicked(int pos) {
        int limbNo = pos / 12;
        int index_LIST = pos - 12 * limbNo;

        if (isTwoPanel) {
            LimbFragment limbFragment = new LimbFragment();
            limbFragment.setLimbID(index_LIST);

            switch (limbNo) {
                case 0:
                    limbFragment.setLimbList(AndroidImageAssets.getHeads());
                    getSupportFragmentManager().beginTransaction().replace(R.id.headContainer, limbFragment).commit();
                    break;
                case 1:
                    limbFragment.setLimbList(AndroidImageAssets.getBodies());
                    getSupportFragmentManager().beginTransaction().replace(R.id.bodyContainer, limbFragment).commit();
                    break;
                case 2:
                    limbFragment.setLimbList(AndroidImageAssets.getLegs());
                    getSupportFragmentManager().beginTransaction().replace(R.id.legContainer, limbFragment).commit();
                    break;
            }

        } else {
            switch (limbNo) {
                case 0:
                    index_HEAD = index_LIST;
                    break;
                case 1:
                    index_BODY = index_LIST;
                    break;
                case 2:
                    index_LEG = index_LIST;
                    break;
            }
        }

        Bundle limb_INDEX = new Bundle();
        limb_INDEX.putInt("headIndex", index_HEAD);
        limb_INDEX.putInt("bodyIndex", index_BODY);
        limb_INDEX.putInt("legIndex", index_LEG);

        final Intent prepareNextIntent = new Intent(this, AndroidMeActivity.class);
        prepareNextIntent.putExtras(limb_INDEX);

        Button startBTN = findViewById(R.id.allStartBtn);
        startBTN.setOnClickListener(view -> startActivity(prepareNextIntent));
    }

    public void initializeLimbFragments(){
        FragmentManager supportFragmentManager = getSupportFragmentManager();
        if (findViewById(R.id.android_me_linear_layout) != null) {
            isTwoPanel = true;

            Button allStartBTN = findViewById(R.id.allStartBtn);
            allStartBTN.setVisibility(View.GONE);

            GridView everyItemGRID = findViewById(R.id.everyItemGrid);
            everyItemGRID.setNumColumns(COLUMN_COUNT);



            LimbFragment limbFragment_HEADS = new LimbFragment();
            limbFragment_HEADS.setLimbList(AndroidImageAssets.getHeads());
            supportFragmentManager.beginTransaction().add(R.id.headContainer, limbFragment_HEADS).commit();

            LimbFragment limbFragment_BODIES = new LimbFragment();
            limbFragment_BODIES.setLimbList(AndroidImageAssets.getBodies());
            supportFragmentManager.beginTransaction().add(R.id.bodyContainer, limbFragment_BODIES).commit();

            LimbFragment limbFragment_LEGS = new LimbFragment();
            limbFragment_LEGS.setLimbList(AndroidImageAssets.getLegs());
            supportFragmentManager.beginTransaction().add(R.id.legContainer, limbFragment_LEGS).commit();
        }
    }

}