package com.msu.androidmee.ui;



import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.content.Context;
import android.os.Bundle;
import com.msu.androidmee.R;
import android.view.View;
import com.msu.androidmee.data.AndroidImageAssets;
import android.widget.GridView;

public class EveryItemFragment extends Fragment {

    OnItemClicked itemClicked;


    public interface OnItemClicked {
        void onItemPicked(int pos);
    }


    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        try {
            itemClicked = (OnItemClicked) context;
        } catch (ClassCastException e) {
            e.printStackTrace();
        }
    }

    public EveryItemFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        final View root = inflater.inflate(R.layout.fragment_every_item, container, false);
        GridView everyItemGrid = root.findViewById(R.id.everyItemGrid);

        MasterListAdapter masterLAdapter = new MasterListAdapter(getContext(), AndroidImageAssets.getAll());
        everyItemGrid.setAdapter(masterLAdapter);

        everyItemGrid.setOnItemClickListener((adapterView, view, position, l) -> itemClicked.onItemPicked(position));

        return root;
    }

}
